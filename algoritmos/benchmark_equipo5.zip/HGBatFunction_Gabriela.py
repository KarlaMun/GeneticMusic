import random
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# HGBat Function - Gabriela Lujan A0154904

# Definimos la HGBat Function como la nueva función objetivo
def hgbat_function(x):
    a = np.array([-10, -5])
    term1 = np.sum((x - a) * 2) * 2
    term2 = (np.sum(x - a) ** 2) / 1e6
    return term1 + term2

# Parámetros de la funcion y rango de evaluacion
population_size = 200
crossover_rate = 0.9
mutation_rate = 0.05
mRate = 0.2
cRate = 0.8
generations = 1000 
patience = 100 
dimensiones = 2
lower_bound = -20
upper_bound = 20
tournament_size = 3

# GFuncion para crear un individuo aleatorio
def create_individual():
    return np.random.uniform(lower_bound, upper_bound, dimensiones)

# Función de crossover
def combine(parent_a, parent_b, c_rate):
    if random.random() <= c_rate:
        c_point = np.random.randint(1, len(parent_a))
        offspring_a = np.concatenate((parent_a[:c_point], parent_b[c_point:]))
        offspring_b = np.concatenate((parent_b[:c_point], parent_a[c_point:]))
    else:
        offspring_a, offspring_b = np.copy(parent_a), np.copy(parent_b)
    return offspring_a, offspring_b

# Función de mutación
def mutate(individual, m_rate):
    for i in range(len(individual)):
        if random.random() <= m_rate:
            individual[i] = np.random.uniform(lower_bound, upper_bound)
    return individual

# Evaluar un individuo usando la HGBat Function
def evaluate(individual):
    return -hgbat_function(individual)  # Queremos minimizar la función

# Selección por torneo
def select(population, evaluation, tournament_size):
    tournament = random.sample(range(len(population)), tournament_size)
    return population[max(tournament, key=lambda i: evaluation[i])]

# Algoritmo genético principal
def genetic_algorithm(population_size, c_rate, m_rate, generations):
    population = [create_individual() for _ in range(population_size)]
    best_individual = None
    best_evaluation = float('-inf')
    
    for gen in range(generations):
        evaluation = [evaluate(ind) for ind in population]
        
        if max(evaluation) > best_evaluation:
            best_index = evaluation.index(max(evaluation))
            best_individual = population[best_index]
            best_evaluation = evaluation[best_index]
        
        new_population = []
        for _ in range(population_size // 2):
            parent_a = select(population, evaluation, tournament_size)
            parent_b = select(population, evaluation, tournament_size)
            offspring_a, offspring_b = combine(parent_a, parent_b, c_rate)
            new_population.extend([mutate(offspring_a, m_rate), mutate(offspring_b, m_rate)])
        
        population = new_population
    
    return best_individual, -best_evaluation  # Volvemos a positivo el valor para la función objetivo

# Ejecutar el algoritmo genético
best_solution, best_value = genetic_algorithm(population_size, crossover_rate, mutation_rate, generations)

# Mostrar el resultado final
print(f"Mejor solución: {best_solution}")
print(f"Valor óptimo encontrado: {best_value}")

# Gráfica
x_range = np.linspace(lower_bound, upper_bound, 40)
y_range = np.linspace(lower_bound, upper_bound, 40)
X, Y = np.meshgrid(x_range, y_range)
Z = np.zeros((len(x_range), len(y_range)))

for i in range(len(x_range)):
    for j in range(len(y_range)):
        Z[i][j] = hgbat_function(np.array([X[i][j], Y[i][j]]))

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')
surf = ax.plot_surface(X, Y, Z, cmap='plasma', edgecolor='none')
cbar = fig.colorbar(surf)

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('HGBat Function')

plt.show()