#Ariel
import random
import numpy as np

def ackley_function(x, y):
    term1 = -20.0 * np.exp(-0.2 * np.sqrt(0.5 * (x**2 + y**2)))
    term2 = -np.exp(0.5 * (np.cos(2 * np.pi * x) + np.cos(2 * np.pi * y)))
    term3 = np.exp(1) + 20.0
    return term1 + term2 + term3

def create_individual():
    return np.array([random.uniform(-100, 100), random.uniform(-100, 100)])

def evaluate(individual):
    x, y = -individual
    return ackley_function(x, y)

def mutate(individual, MUTATION_RATE):
  if random.random() <= MUTATION_RATE:
    individual += np.random.normal(0, 0.1, size=individual.shape)
    individual = np.clip(individual, -100, 100) 
  return individual

def combine(parent_a, parent_b, c_rate):
    if random.random() <= c_rate:
        alpha = random.random()
        offspring_a = alpha * parent_a + (1 - alpha) * parent_b
        offspring_b = alpha * parent_b + (1 - alpha) * parent_a
    else:
        offspring_a, offspring_b = np.copy(parent_a), np.copy(parent_b)
    return offspring_a, offspring_b

def select(population, evaluation, tournament_size):
    tournament = random.sample(range(len(population)), tournament_size)
    return population[min(tournament, key=lambda i: evaluation[i])]

def genetic_algorithm(population_size, c_rate, m_rate, generations):
    population = [create_individual() for _ in range(population_size)]
    best_individual = None
    best_evaluation = float('inf')

    for _ in range(generations):
        evaluation = [evaluate(ind) for ind in population]

        if max(evaluation) < best_evaluation:
            best_index = evaluation.index(min(evaluation))
            best_individual = population[best_index]
            best_evaluation = evaluation[best_index]

        new_population = []
        for _ in range(population_size // 2):
            parent_a = select(population, evaluation, 3)
            parent_b = select(population, evaluation, 3)
            offspring_a, offspring_b = combine(parent_a, parent_b, c_rate)
            new_population.extend([mutate(offspring_a, m_rate), mutate(offspring_b, m_rate)])

        population = new_population

    return best_individual, best_evaluation

POPULATION_SIZE = 20000
CROSSOVER_RATE = 0.7
MUTATION_RATE = 0.3
GENERATIONS = 100
TOURNAMENT_SIZE = 3

best_solution, best_value = genetic_algorithm(POPULATION_SIZE, CROSSOVER_RATE, MUTATION_RATE, GENERATIONS)
print(best_solution)
print(best_value)