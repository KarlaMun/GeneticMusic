# Santiago Mora Cruz

import random
import numpy

minvalores, maxvalores = -2, 2

def bent_cigar_function(x, y):
    return x**2 + 1e6 * y**2

# Inicialización de un individuo con variables discretas (número de objetos)
def createIndividual():
    return numpy.array([numpy.random.uniform(minvalores, maxvalores) for _ in range(2)])

# Función de evaluación (fitness) que calcula el valor total y penaliza si excede la capacidad
def evaluate(individual):
    x, y = individual
    result = bent_cigar_function(x, y)

    return result

# Función de cruce (one point crossover) para individuos con cantidades de objetos
def combine(parentA, parentB, cRate):
    if random.random() <= cRate:
        cPoint = numpy.random.randint(1, len(parentA))
        offspringA = numpy.append(parentA[:cPoint], parentB[cPoint:])
        offspringB = numpy.append(parentB[:cPoint], parentA[cPoint:])
    else:
        offspringA = numpy.copy(parentA)
        offspringB = numpy.copy(parentB)
    return offspringA, offspringB

# Función de mutación que cambia aleatoriamente la cantidad de un objeto
def mutate(individual, mRate):
    for i in range(len(individual)):
        if random.random() <= mRate:
            # La cantidad de mutación está limitada por el máximo disponible para ese objeto
            individual[i] = numpy.random.uniform(minvalores, maxvalores)
    return individual

# Función de selección por torneo
def select(population, evaluation, tournamentSize):
    winner = numpy.random.randint(0, len(population))
    for _ in range(tournamentSize - 1):
        rival = numpy.random.randint(0, len(population))
        if evaluation[rival] < evaluation[winner]:  # Cambiado a menor que para minimizar
            winner = rival
    return population[winner]

# Algoritmo genético para el problema de la mochila
def geneticAlgorithm(populationSize, cRate, mRate, generations):
    # Crear la población inicial
    population = [createIndividual() for _ in range(populationSize)]
    evaluation = [evaluate(ind) for ind in population]

    # Mantener registro del mejor individuo
    # Mantener registro del mejor individuo
    bestIndividual = population[numpy.argmin(evaluation)]  # Cambiado a argmin para minimizar
    bestEvaluation = min(evaluation)

    # Proceso evolutivo
    for _ in range(generations):
        newPopulation = []
        for _ in range(populationSize // 2):
            parentA = select(population, evaluation, 3)
            parentB = select(population, evaluation, 3)
            offspringA, offspringB = combine(parentA, parentB, cRate)
            newPopulation.append(offspringA)
            newPopulation.append(offspringB)
        
        population = [mutate(ind, mRate) for ind in newPopulation]
        evaluation = [evaluate(ind) for ind in population]
        
        # Actualizar el mejor individuo encontrado
        min_eval_idx = numpy.argmin(evaluation)  # Cambiado a argmin para minimizar
        if evaluation[min_eval_idx] < bestEvaluation:  # Cambiado a menor que para minimizar
            bestEvaluation = evaluation[min_eval_idx]
            bestIndividual = population[min_eval_idx]

   
    return bestIndividual, bestEvaluation

# Resolver el problema de la mochila
solution, evaluation = geneticAlgorithm(200, 0.7, 0.3, 2000)
print("Mejor solución encontrada:", solution)
print("Valor de la solución:", evaluation)
