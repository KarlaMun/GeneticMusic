import random
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# High Conditioned Elliptic Function - Gabriela Lujan A01254904

# Definimos la High Conditioned Elliptic Function que ahora sera nuestra funcion objetivo
def high_conditioned_elliptic_function(x):
    a = 1e6  
    d = len(x)  
    return np.sum([a*((i)/(d-1)) * (x[i]*2) for i in range(d)])

# Parámetros
population_size = 200
crossover_rate = 0.9
mutation_rate = 0.05
mRate = 0.2
cRate = 0.8
generations = 1000 
patience = 100  # Número de generaciones sin mejora
dimensiones = 2
lower_bound = -2
upper_bound = 2
tournament_size = 3

# Funcion para crear un individuo aleatorio
def create_individual():
    return np.random.uniform(lower_bound, upper_bound, dimensiones)

# Función de crossover
def combine(parent_a, parent_b, c_rate):
    if random.random() <= c_rate:
        c_point = np.random.randint(1, len(parent_a))
        offspring_a = np.concatenate((parent_a[:c_point], parent_b[c_point:]))
        offspring_b = np.concatenate((parent_b[:c_point], parent_a[c_point:]))
    else:
        offspring_a, offspring_b = np.copy(parent_a), np.copy(parent_b)
    return offspring_a, offspring_b

# Función de mutación
def mutate(individual, m_rate):
    for i in range(len(individual)):
        if random.random() <= m_rate:
            individual[i] = np.random.uniform(lower_bound, upper_bound)
    return individual

# Evaluamos individuo co la High Conditioned Elliptic Function
def evaluate(individual):
    return -high_conditioned_elliptic_function(individual)  # Minimizamos funcion (agregamos -)

# Selección por torneo
def select(population, evaluation, tournament_size):
    tournament = random.sample(range(len(population)), tournament_size)
    return population[max(tournament, key=lambda i: evaluation[i])]

# Algoritmo Genético 
def genetic_algorithm(population_size, c_rate, m_rate, generations):
    population = [create_individual() for _ in range(population_size)]
    best_individual = None
    best_evaluation = float('-inf')
    
    for gen in range(generations):
        evaluation = [evaluate(ind) for ind in population]
        
        if max(evaluation) > best_evaluation:
            best_index = evaluation.index(max(evaluation))
            best_individual = population[best_index]
            best_evaluation = evaluation[best_index]
        
        new_population = []
        for _ in range(population_size // 2):
            parent_a = select(population, evaluation, tournament_size)
            parent_b = select(population, evaluation, tournament_size)
            offspring_a, offspring_b = combine(parent_a, parent_b, c_rate)
            new_population.extend([mutate(offspring_a, m_rate), mutate(offspring_b, m_rate)])
        
        population = new_population
    
    return best_individual, -best_evaluation  # Volvemos a positivo el valor para la función objetivo

# Encontramos solucion con algoritmo
best_solution, best_value = genetic_algorithm(population_size, crossover_rate, mutation_rate, generations)

print(f"Mejor solución: {best_solution}")
print(f"Valor óptimo encontrado: {best_value}")

# Graficamos 
x_range = y_range = np.linspace(lower_bound, upper_bound, 100)
X, Y = np.meshgrid(x_range, y_range)
Z = np.zeros_like(X)

# Evaluar la función en cada punto de la malla
for i in range(len(x_range)):
    for j in range(len(y_range)):
        point = [X[i, j], Y[i, j]]
        Z[i, j] = high_conditioned_elliptic_function(point)

# Crear la gráfica 3D
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
surf = ax.plot_surface(X, Y, Z, cmap='plasma', edgecolor='none')
fig.colorbar(surf)

# Etiquetas y título
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('High Conditioned Elliptic Function')

plt.show()